Install visual code
install live code in visual code and run
